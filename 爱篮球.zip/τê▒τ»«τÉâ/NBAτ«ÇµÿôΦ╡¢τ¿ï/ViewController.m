//
//  ViewController.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/24.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "ViewController.h"
#import "MenuView.h"
#import "JKSideSlipView.h"
#import "AFNetworking.h"
#import "MBProgressHUD+KR.h"
#import "NABDataManager.h"
#import "AppDelegate.h"
#import "NBAHotGameTableViewCell.h"
#import "NBALiveGameTableViewCell.h"
#import "NBALiveVsGame.h"
#import "NBALiveGameTr.h"
#import "UIImageView+WebCache.h"
#import "NBAWebViewController.h"
#import "NBAHeraldTableViewController.h"
#import "NBAMyInfoViewController.h"

@interface ViewController ()<UITableViewDataSource,UITableViewDelegate,NBALiveGameTableViewCellDelegate,NBAHotGameTableViewCellDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tabelView;

//直播比赛信息
@property(nonatomic,strong)NSDictionary *gameDic;

//热点比赛
@property(nonatomic,strong)NSArray *lives;
@property(nonatomic,strong)NSArray *livelink;

//比赛列表
@property(nonatomic,strong)NSArray *liveTr;
/** 侧边划出视图*/
@property(nonatomic,strong)JKSideSlipView * sideSlipView;

//按钮的index
@property(nonatomic,assign)NSInteger clickIndex;
@property(nonatomic,strong)NSString *urlStr;


@end

@implementation ViewController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self sendRequestToServer];
    
}
-(void)sendRequestToServer
{
//    [MBProgressHUD showMessage:@"Loading..."];

    AFHTTPSessionManager *manage = [AFHTTPSessionManager manager];
    NSDictionary *parameter = @{@"key":APPKEY};
    [manage POST:MATCHESLIST parameters:parameter success:^(NSURLSessionDataTask *task, id responseObject) {
//        [MBProgressHUD hideHUD];
//        NSLog(@"%@",responseObject);
        AppDelegate *appDelegate = [[UIApplication sharedApplication]delegate];
        appDelegate.respondObj = responseObject;
        self.gameDic = [NABDataManager getLvieGameTimeData:appDelegate.respondObj];
        self.lives = self.gameDic[@"live"];
        self.liveTr = self.gameDic[@"tr"];
        self.livelink = self.gameDic[@"livelink"];
       
        
        [self.tabelView reloadData];
//        [NABDataManager getAllNBADataWithJson:responseObject];
    } failure:^(NSURLSessionDataTask *task, NSError *error) {
//        [MBProgressHUD hideHUD];
        [MBProgressHUD HUDForView:self.view];
        NSLog(@"获取数据失败:%@",error);
//        [MBProgressHUD showError:@"获取数据失败"];
                [MBProgressHUD hideHUD];

    }];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    //侧边划出
    [self setupMenu];
//    self.tabelView.delegate = self;
//    self.tabelView.dataSource = self;
    
    
//    [self.tabelView reloadData];
    

  
}


-(void)setupMenu{
    self.sideSlipView = [[JKSideSlipView alloc]initWithSender:self];
    self.sideSlipView.backgroundColor = [UIColor lightGrayColor];
    
    MenuView *menuView =[MenuView menuView];
    [menuView didSelectRowAtIndexPath:^(id cell, NSIndexPath *indexPath) {
        switch (indexPath.row) {
            case 0:
                return ;
                break;
            case 1:
            {
                NBAMyInfoViewController *myinfoVc = [self.storyboard instantiateViewControllerWithIdentifier:@"myinfo"];
                UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:myinfoVc];
                [self presentViewController:navi animated:YES completion:nil];
            }
                break;
            case 2:{
                //这个控制没有在storyboard里通过连线  必须先实例化这个控制器对象 才可以正常使用
//                NBAHeraldTableViewController *heraldView = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]instantiateViewControllerWithIdentifier:@"herald"];
                NBAHeraldTableViewController *heraldView = [self.storyboard instantiateViewControllerWithIdentifier:@"herald"];
                UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:heraldView];
                [self presentViewController:navi animated:YES completion:nil];

           
                
                break;
            }
            default:
            {
                NSLog(@"...");
                break;
            }
        }
    }];
    menuView.items = @[@{},@{@"title":@"我的主页"},@{@"title":@"明日预告"},@{@"title":@"我的球队"}];
    [self.sideSlipView setContentView:menuView];
    [self.view addSubview:self.sideSlipView];
    
    
    
    
}
- (IBAction)me:(UIBarButtonItem *)sender {
    
    [self.sideSlipView switchMenu];
    
    
}


#pragma mark UITabelViewDalegate相关方法
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0 ) {
        return self.lives.count;
    }else{
        return self.liveTr.count;
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section ==0) {
        NBAHotGameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"hotCell"];
        NBALiveVsGame *live = self.lives[0];
        cell.play1_name.text = live.player1;
        cell.play2_name.text = live.player2;
        [cell.play1_image setImageWithURL:[NSURL URLWithString:live.player1logobig]placeholderImage:[UIImage imageNamed:@"nbaTeam"]];
        [cell.play2_image setImageWithURL:[NSURL URLWithString:live.player2logobig]placeholderImage:[UIImage imageNamed:@"nbaTeam"]];
        cell.play1_info.text = live.player1info;
        cell.play2_info.text = live.player2info;
        cell.play1_location.text = live.player1location;
        cell.play2_location.text = live.player2location;
        
        cell.title.text = live.title;
        cell.delegate = self;
        if (live.status == 0) {
            cell.score.text = @"VS";
            cell.statusBtn.hidden = YES;
            cell.statusBtn2.hidden =YES;
        }else if(live.status ==1 ||live.status ==2){
            NSDictionary *dic1 = self.livelink[0];
            NSDictionary *dic2 = self.livelink[1];
            cell.score.text = live.score;
            cell.statusBtn.hidden = NO;
            cell.statusBtn.titleLabel.text = dic1[@"text"];
            cell.url = dic1[@"url"];
            cell.statusBtn.hidden = NO;
            cell.statusBtn2.titleLabel.text = dic2[@"text"];
        }
        
        
        return cell;
    }else{
    
        NBALiveGameTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"liveCell"];
        NBALiveGameTr *tr = self.liveTr[indexPath.row];
        cell.play1_name.text = tr.player1;
        cell.play2_name.text = tr.player2;
        cell.delegate = self;
        [cell.play1_image setImageWithURL:[NSURL URLWithString:tr.player1logo] placeholderImage:[UIImage imageNamed:@"nbaTeam"]];
        [cell.play2_image setImageWithURL:[NSURL URLWithString:tr.player2logo]placeholderImage:[UIImage imageNamed:@"nbaTeam"]];
        cell.time.text = tr.time;
        cell.goWeb1.tag = indexPath.row;

        cell.urlStr = tr.m_link1url;
        [cell.goWeb1 setTitle:tr.link1text forState:(UIControlStateNormal)];
        [cell.goWeb2 setTitle:tr.link2text forState:(UIControlStateNormal)];
        //把值存在urlstr中 方便传值
//        self.urlStr = tr.m_link1url;
        if (tr.status == 0) {
            cell.score.text =@"VS";
            cell.status.text = @"未开始";
            cell.goWeb1.hidden = YES;
            cell.goWeb2.hidden = YES;
        }else if (tr.status ==1) {
            cell.score.text = tr.score;
            cell.status.text = @"比赛中";
        }else{
            cell.score.text = tr.score;
            cell.status.text = @"已结束";
        }
        
        
        
    return cell;
    }
}
//-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
//{
//    if (indexPath.section ==0) {
//        NBAWebViewController *webView = [NBAWebViewController new];
//        NSDictionary *dic1 = self.livelink[0];
//
//        NSString *urlStr =dic1[@"url"];
//        webView.url = [NSURL URLWithString:urlStr];
//        UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:webView];
//        [self presentViewController:navi animated:YES completion:nil];
//        
//    }else {
//        NBAWebViewController *webView = [NBAWebViewController new];
//         NBALiveGameTr *tr = self.liveTr[indexPath.row];
//        webView.url = [NSURL URLWithString:tr.m_link1url];
//        UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:webView];
//        [self presentViewController:navi animated:YES completion:nil];
//
//    }
//}
#pragma mark NBALiveGameTableViewCellDelegate
-(void)clickBtn:(UIButton *)button withUrl:(NSString *)url
{
    NBAWebViewController *webView = [NBAWebViewController new];
    
    webView.url = [NSURL URLWithString:url];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:webView];
    [self presentViewController:navi animated:YES completion:nil];
}
-(void)choseTerm:(UIButton *)button andurl:(NSString *)url
{
   

    NBAWebViewController *webView = [NBAWebViewController new];
  
    webView.url = [NSURL URLWithString:url];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:webView];
    [self presentViewController:navi animated:YES completion:nil];

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row ==0 && indexPath.section ==0) {
        return 140;
    }else{
        return 110;
    }
}
-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (section ==0) {
        return @"热门比赛";
    }else{
        return @"直播列表";
    }
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
