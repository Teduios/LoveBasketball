//
//  NBAHeraldGame.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NBAHeraldGame : NSObject

@property(nonatomic,strong)NSString *player1;
@property(nonatomic,strong)NSString *player1logo;
@property(nonatomic,strong)NSString *player2;
@property(nonatomic,strong)NSString *player2logo;
@property(nonatomic,strong)NSString *score;
@property(nonatomic,strong)NSString *time;
@property(nonatomic,getter=isIsClock)BOOL isClock;

+(NBAHeraldGame*)getANBAHeraldGameWithDic:(NSDictionary*)dic;
@end
