//
//  NBAHeraldGame.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAHeraldGame.h"
#import "NABDataManager.h"
@implementation NBAHeraldGame


+(NBAHeraldGame *)getANBAHeraldGameWithDic:(NSDictionary *)dic
{
    NBAHeraldGame *game = [NBAHeraldGame new];
    game.player1 = dic[@"player1"];
    game.player1logo = dic[@"player1logo"];
    game.player2 = dic[@"player2"];
    game.player2logo = dic[@"player2logo"];
    game.score = dic[@"score"];
    game.time = dic[@"time"];
    game.isClock = NO;
    return game;
}
@end
