//
//  NBALiveGameTr.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NBALiveGameTr : NSObject

@property (nonatomic, strong) NSString *link1text;
@property (nonatomic, strong) NSString *link1url;
@property (nonatomic, strong) NSString *link2text;
@property (nonatomic, strong) NSString *link2url;
@property (nonatomic, strong) NSString *m_link1url;
@property (nonatomic, strong) NSString *m_link2url;
@property (nonatomic, strong) NSString *player1;
@property (nonatomic, strong) NSString *player1logo;
@property (nonatomic, strong) NSString *player1logobig;
@property (nonatomic, strong) NSString *player1url;
@property (nonatomic, strong) NSString *player2;
@property (nonatomic, strong) NSString *player2logo;
@property (nonatomic, strong) NSString *player2logobig;
@property (nonatomic, strong) NSString *player2url;
@property (nonatomic, strong) NSString *score;
@property (nonatomic, assign) int status;
@property (nonatomic, strong) NSString *time;
@end
