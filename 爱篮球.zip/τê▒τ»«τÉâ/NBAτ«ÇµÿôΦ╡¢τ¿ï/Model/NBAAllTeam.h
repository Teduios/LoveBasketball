//
//  NBAAllTeam.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NBAAllTeam : NSObject

@property(nonatomic,strong)NSString *name;
@property(nonatomic,strong)NSString *url;


@end
