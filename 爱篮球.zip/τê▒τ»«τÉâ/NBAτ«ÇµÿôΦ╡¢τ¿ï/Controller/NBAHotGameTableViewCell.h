//
//  NBAHotGameTableViewCell.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NBALiveVsGame.h"

@protocol NBAHotGameTableViewCellDelegate <NSObject>
/**代理方法*/
-(void)clickBtn:(UIButton*)button  withUrl:(NSString *)url;
@end


@interface NBAHotGameTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *play1_image;

@property (weak, nonatomic) IBOutlet UIImageView *play2_image;

@property (weak, nonatomic) IBOutlet UILabel *play1_name;
@property (weak, nonatomic) IBOutlet UILabel *play2_name;

@property (weak, nonatomic) IBOutlet UILabel *play1_info;
@property (weak, nonatomic) IBOutlet UILabel *play2_info;

@property (weak, nonatomic) IBOutlet UILabel *play1_location;
@property (weak, nonatomic) IBOutlet UILabel *play2_location;

@property (weak, nonatomic) IBOutlet UILabel *title;
//比分
@property (weak, nonatomic) IBOutlet UILabel *score;
@property (weak, nonatomic) IBOutlet UIButton *statusBtn;
@property (weak, nonatomic) IBOutlet UIButton *statusBtn2;

@property(nonatomic,strong)NSString *url;

@property(nonatomic,weak)id<NBAHotGameTableViewCellDelegate> delegate;




@end
