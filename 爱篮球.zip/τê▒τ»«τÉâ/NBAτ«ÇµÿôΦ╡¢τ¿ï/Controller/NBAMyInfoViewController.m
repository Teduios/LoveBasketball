//
//  NBAMyInfoViewController.m
//  NBA简易赛程
//
//  Created by tarena on 16/3/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAMyInfoViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
#import "NBAAnnotation.h"
@interface NBAMyInfoViewController ()<CLLocationManagerDelegate,MKMapViewDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;

@property(nonatomic,strong)CLLocationManager *manager;
@end

@implementation NBAMyInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:self action:@selector(back)];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    if ([[UIDevice currentDevice].systemVersion doubleValue]>= 8.0) {
        [self.manager requestWhenInUseAuthorization];
    }else{
        [self.manager startUpdatingLocation];
    }
    
    self.mapView.delegate = self;
    self.mapView.rotateEnabled = NO;
    self.mapView.mapType = MKMapTypeHybrid;
    self.mapView.userTrackingMode = MKUserTrackingModeFollow;
}

-(void)back{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark  location
-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
        case kCLAuthorizationStatusAuthorizedWhenInUse:
            self.manager.distanceFilter = 1000;
            [self.manager startUpdatingLocation];
            break;
        case kCLAuthorizationStatusNotDetermined:
            NSLog(@"用户不允许定位");
        default:
            break;
    }
    
}

-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    for (CLLocation *location in locations) {
        NSLog(@"(%f,%f)",location.coordinate.latitude,location.coordinate.longitude);
    }
    self.manager = nil;
    [self.manager stopUpdatingLocation];
    
}

#pragma mark mapview
-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    userLocation.title = @"你的位置";
    
}
-(MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id<MKAnnotation>)annotation
{
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;
    }
    //重用机制
    
    static NSString *identifier = @"annotation";
    MKAnnotationView *annoView = [mapView dequeueReusableAnnotationViewWithIdentifier:identifier];
    
    if (!annoView) {
        annoView =[[MKAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:identifier];
        
        //        annoView.image = [UIImage imageNamed:@"1111.png"];
        NBAAnnotation *anno =(NBAAnnotation *)annotation;
        annoView.image = anno.image;
        
        //设置允许弹出
        annoView.canShowCallout =YES;
        
        //设置弹出框的左右视图
        annoView.leftCalloutAccessoryView =[[UISwitch alloc]init];
        annoView.rightCalloutAccessoryView =[UIButton buttonWithType:UIButtonTypeDetailDisclosure];
        
    }else {
        annoView.annotation =annotation;
    }
    return annoView;

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
