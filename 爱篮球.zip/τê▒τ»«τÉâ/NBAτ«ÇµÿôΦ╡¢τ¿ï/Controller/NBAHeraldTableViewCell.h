//
//  NBAHeraldTableViewCell.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NBAHeraldTableViewCellDelegate <NSObject>

-(void)makeAClockBtn:(UIButton*)btn andisClock:(BOOL)isClock andtag:(NSInteger)tag;

@end


@interface NBAHeraldTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *play1logo;
@property (weak, nonatomic) IBOutlet UIImageView *play2logo;
@property (weak, nonatomic) IBOutlet UILabel *play1name;
@property (weak, nonatomic) IBOutlet UILabel *play2name;

@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UIButton *clockBtn;

@property (nonatomic,assign)BOOL isOpen;

@property(nonatomic,weak)id<NBAHeraldTableViewCellDelegate> delegate;

@end
