//
//  NBAAllTeamViewController.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAAllTeamViewController.h"
#import "AFNetworking.h"
#import "NABDataManager.h"
#import "NBAAllTeam.h"
#import "AppDelegate.h"
#import "NBAWebViewController.h"

@interface NBAAllTeamViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITableView *teamTableView;

@property(nonatomic,strong)NSArray *allTeamArray;


@end

@implementation NBAAllTeamViewController

-(NSArray *)allTeamArray
{
    if (!_allTeamArray) {
        _allTeamArray =[NSArray array];
    }
    
    return _allTeamArray;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self sendRequestToServer];
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.tabBarController.tabBar.hidden = NO;
    [self.teamTableView reloadData];
}


-(void)sendRequestToServer
{

    AppDelegate *appDelegate = [[UIApplication sharedApplication]delegate];
    self.allTeamArray = [NABDataManager getAllTeamData:appDelegate.respondObj];
//    AFHTTPSessionManager *manage = [AFHTTPSessionManager manager];
//    NSDictionary *parameter = @{@"key":APPKEY};
//    [manage POST:MATCHESLIST parameters:parameter success:^(NSURLSessionDataTask *task, id responseObject) {
//   
//
//        self.allTeamArray = [NABDataManager getAllTeamData:responseObject];
//        
//        NSLog(@"%ld",self.allTeamArray.count);
//        [self.teamTableView reloadData];
//    } failure:^(NSURLSessionDataTask *task, NSError *error) {
//
//        NSLog(@"获取数据失败:%@",error);
//        
//    }];

}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.allTeamArray.count;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    NBAAllTeam *team = self.allTeamArray[indexPath.row];
//    NSLog(@"%@",team.name);
    cell.textLabel.text =team.name;
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NBAAllTeam  *team = self.allTeamArray[indexPath.row];
    
    NBAWebViewController *webView = [NBAWebViewController new];
  
    
    NSString *urlStr =team.url;
    webView.url = [NSURL URLWithString:urlStr];
    UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:webView];
    [self presentViewController:navi animated:YES completion:nil];
}


@end
