//
//  NBAHotGameTableViewCell.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/26.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAHotGameTableViewCell.h"
#import "UIImageView+WebCache.h"

@implementation NBAHotGameTableViewCell


- (void)awakeFromNib {
    // Initialization code
}
- (IBAction)goweb:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(clickBtn:withUrl:)]) {
        sender.tag = self.tag;
        [self.delegate clickBtn:sender withUrl:self.url];
    }
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


@end
