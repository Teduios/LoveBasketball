//
//  NBALiveGameTableViewCell.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol NBALiveGameTableViewCellDelegate <NSObject>

-(void)choseTerm:(UIButton *)button andurl:(NSString*)url;

@end


@interface NBALiveGameTableViewCell : UITableViewCell

@property(nonatomic,strong)NSString *urlStr;

@property (weak, nonatomic) IBOutlet UILabel *play1_name;
@property (weak, nonatomic) IBOutlet UILabel *play2_name;
@property (weak, nonatomic) IBOutlet UIImageView *play1_image;
@property (weak, nonatomic) IBOutlet UIImageView *play2_image;
@property (weak, nonatomic) IBOutlet UILabel *score;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *status;
@property (weak, nonatomic) IBOutlet UIButton *goWeb1;
@property (weak, nonatomic) IBOutlet UIButton *goWeb2;

@property(nonatomic,assign)id<NBALiveGameTableViewCellDelegate> delegate;

@end
