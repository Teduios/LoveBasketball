//
//  NBALiveGameTableViewCell.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBALiveGameTableViewCell.h"

@implementation NBALiveGameTableViewCell

- (void)awakeFromNib {
    // Initialization code
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (IBAction)goweb:(UIButton *)sender {
    if ([self.delegate respondsToSelector:@selector(choseTerm:andurl:)]) {
        sender.tag = self.tag;
        
        [self.delegate choseTerm:sender andurl:self.urlStr];
    }
}

@end
