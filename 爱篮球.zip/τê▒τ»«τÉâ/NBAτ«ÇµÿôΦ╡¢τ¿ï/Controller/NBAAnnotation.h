//
//  NBAAnnotation.h
//  NBA简易赛程
//
//  Created by tarena on 16/3/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>

@interface NBAAnnotation : NSObject<MKAnnotation>
//大头针的地理位置
@property (nonatomic) CLLocationCoordinate2D coordinate;

// 标识大头针的两个title标题
@property (nonatomic, copy,nonnull) NSString *title;
@property (nonatomic, copy,nonnull) NSString *subtitle;
@property (nonatomic,copy,nonnull) UIImage *image;
@end
