//
//  NBAResDetailsViewController.m
//  NBA简易赛程
//
//  Created by tarena on 16/3/1.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAResDetailsViewController.h"
#import <ImageIO/ImageIO.h>

@interface NBAResDetailsViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *headView;
@property (weak, nonatomic) IBOutlet UITextView *textView;

@end

@implementation NBAResDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self sendHeadView];
    
    
}
-(void)sendHeadView
{
        NSURL *url = [[NSBundle mainBundle] URLForResource:@"pika.gif" withExtension:nil];
    CGImageSourceRef csf = CGImageSourceCreateWithURL((__bridge CFTypeRef) url, NULL);
    size_t const count = CGImageSourceGetCount(csf);
    UIImage *frames[count];
    CGImageRef images[count];
    for (size_t i = 0; i < count; ++i) {
        images[i] = CGImageSourceCreateImageAtIndex(csf, i, NULL);
        UIImage *image =[[UIImage alloc] initWithCGImage:images[i]];
        frames[i] = image;
        CFRelease(images[i]);
    }
    
    UIImage *const animation = [UIImage animatedImageWithImages:[NSArray arrayWithObjects:frames count:count] duration:1.4];
    
    [self.headView setImage:animation];
    NSLog(@"xxxx%zu",count);  
    CFRelease(csf);
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
