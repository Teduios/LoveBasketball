//
//  NBAResourceViewController.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/27.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAResourceViewController.h"
#import "NBAResTableViewCell.h"

#define HD_HIGHT 150
#define AD_WIDTH 380

@interface NBAResourceViewController ()<UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
{
    UIScrollView *_scrollView;
    UIImageView *_leftImageVIew;
    UIImageView *_rightView;
    UIImageView *_centerView;
    UIPageControl *_pageControl;
    NSInteger _currentImageIndex;
    
}
@property (nonatomic ,strong)NSArray *allAdImages;
@property NSInteger imagecount;
@property (weak, nonatomic) IBOutlet UIView *headView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;



@end

@implementation NBAResourceViewController

-(NSArray *)allAdImages
{
    if (!_allAdImages) {
        _allAdImages = @[@"nba_1",@"nba_2",@"nba_3",@"nba_4"];
    }
    return _allAdImages;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    _imagecount = self.allAdImages.count;
    //记载滚动视图
    [self addScrollView];
    
    //加载图片
    [self addImageView];
    
    //添pagecontrol
//    [self addPageControl];
    
    //加载默认的第一屏的三张图片
    [self setDefaultImage];
    
    
}
-(void)addScrollView{
    _scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, self.headView.bounds.size.width, HD_HIGHT)];
    [self.view addSubview: _scrollView];
    
    //设置代理
    _scrollView.delegate = self;
    
    //设置size
    _scrollView.contentSize = CGSizeMake(AD_WIDTH*3, self.headView.bounds.size.height);
    
    _scrollView.contentOffset = CGPointMake(AD_WIDTH, 0);
    
    _scrollView.pagingEnabled = YES;
    _scrollView.bounces = NO;
    _scrollView.showsHorizontalScrollIndicator = NO;
    
    
    
}

-(void)addImageView
{
    _leftImageVIew = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, AD_WIDTH, self.headView.bounds.size.height)];
    _leftImageVIew.contentMode = UIViewContentModeScaleToFill;
    _centerView = [[UIImageView alloc]initWithFrame:CGRectMake(AD_WIDTH, 0, AD_WIDTH, self.headView.bounds.size.height)];
    _centerView.contentMode = UIViewContentModeScaleToFill;
    _rightView = [[UIImageView alloc]initWithFrame:CGRectMake(2*AD_WIDTH, 0, AD_WIDTH,self.headView.bounds.size.height)];
    _rightView.contentMode = UIViewContentModeScaleToFill;
    [_scrollView addSubview:_leftImageVIew];
    [_scrollView addSubview:_centerView];
    [_scrollView addSubview:_rightView];
}

-(void)addPageControl
{
    
    _pageControl = [[UIPageControl alloc]init];
    CGSize size = [_pageControl sizeForNumberOfPages:_imagecount];
    //定视图的位置是，为了居中 可以通过设置图示的中心点
    //为了定位 可以使用bounds + center
    _pageControl.bounds = CGRectMake(0, 0, size.width, size.height);
    _pageControl.center = CGPointMake(AD_WIDTH*0.5, 20);
    
    _pageControl.pageIndicatorTintColor = [UIColor grayColor];
    _pageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
    
    _pageControl.numberOfPages = _imagecount;
//    _pageControl.
    [_scrollView addSubview:_pageControl];
}
-(void)setDefaultImage
{
    _leftImageVIew.image = [UIImage imageNamed:self.allAdImages[_imagecount-1]];
    _centerView.image = [UIImage imageNamed:self.allAdImages[0]];
    _rightView.image = [UIImage imageNamed:self.allAdImages[1]];
    
    _currentImageIndex = 0;
//    _pageControl.currentPage = _currentImageIndex;
    
    
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    NSLog(@"移动");
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSLog(@"...");
    
    [self reloadImage];
    //移回中间
    _scrollView.contentOffset = CGPointMake(AD_WIDTH, 0);
    
//    _pageControl.currentPage = _currentImageIndex;
    
    
}

-(void)reloadImage
{
    // NSInteger leftimgaeindex ,rightImgaeindex;
    
    CGPoint offset = _scrollView.contentOffset;
    if (offset.x >AD_WIDTH) {
        
        _currentImageIndex = (_currentImageIndex +1)%_imagecount;
        
        
    }
    else if(offset.x < AD_WIDTH)
    {
        _currentImageIndex = ( _currentImageIndex + _imagecount -1)%_imagecount;
    }
    
    _centerView.image = [UIImage imageNamed:self.allAdImages[_currentImageIndex]];
    _leftImageVIew.image = [UIImage imageNamed:self.allAdImages[(_currentImageIndex +_imagecount-1)%_imagecount]];
    _rightView.image = [UIImage imageNamed:self.allAdImages[(_currentImageIndex+1)%_imagecount]];
    
    
}

//- (void)viewDidLoad {
//    [super viewDidLoad];
//    
//    
//    UIImageView *imageV = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"nba_1"]];
//    imageV.frame = CGRectMake(0, 0, AD_WIDTH, HD_HIGHT);
//    imageV.contentMode = UIViewContentModeScaleToFill;
//    
//    [self.headView addSubview:imageV];
//    
//    
//    
//
//
//}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NBAResTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"resCell"];
    
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}

@end
