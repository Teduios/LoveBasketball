//
//  NBAHeraldTableViewCell.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/29.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NBAHeraldTableViewCell.h"

@implementation NBAHeraldTableViewCell

- (void)awakeFromNib {
    // Initialization code
}
- (IBAction)makeClock:(UIButton*)sender {
    sender.tag = self.tag;
//    sender.selected = !sender.selected;
    if ([self.delegate respondsToSelector:@selector(makeAClockBtn: andisClock: andtag:)]) {
        [self.delegate makeAClockBtn:sender andisClock:self.isOpen andtag:self.tag];
    }
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
