//
//  NABDataManager.m
//  NBA简易赛程
//
//  Created by tarena on 16/2/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "NABDataManager.h"
#import "NBAAllTeam.h"
#import "NBALiveVsGame.h"
#import "NBALiveGameTr.h"
#import "NBAHeraldGame.h"
@implementation NABDataManager




+(NSDictionary *)getAllNBADataWithJson:(id)response
{
    NSDictionary *nbaAllDataDic = response[@"result"];
    
    return nbaAllDataDic;
}
+(NSDictionary *)getLvieGameTimeData:(NSDictionary *)response
{
    
    NSArray *livGameArray = response[@"result"][@"list"][1][@"live"];
    
    NSMutableArray *live = [NSMutableArray array];
    for (NSDictionary *dic in livGameArray) {
        NBALiveVsGame *liveGame = [[NBALiveVsGame alloc]init];
        [liveGame setValuesForKeysWithDictionary:dic];
        [live addObject:liveGame];
    }
//    NSString *liveUrl = response[@"result"][@"list"][1][@"li"][0][@"url"];
    NSArray *livelink = response[@"result"][@"list"][1][@"livelink"];
    
    NSArray *trArray = response[@"result"][@"list"][1][@"tr"];
    NSMutableArray *tr = [NSMutableArray array];
    for (NSDictionary *dic in trArray) {
        NBALiveGameTr *liveTr = [[NBALiveGameTr alloc]init];
        [liveTr setValuesForKeysWithDictionary:dic];
        [tr addObject:liveTr];
    }
    
    NSDictionary *liveDic = [[NSDictionary alloc]initWithObjectsAndKeys:[tr copy],@"tr", live,@"live",livelink,@"livelink",nil];
    
    return liveDic;

}



+(NSArray *)getAllTeamData:(id)response
{
    NSArray *teamarray = response[@"result"][@"teammatch"];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in teamarray) {
        NBAAllTeam *team = [[NBAAllTeam alloc]init];
        [team setValuesForKeysWithDictionary:dic];
        [array addObject:team];
    }
    return [array copy];
    
}

+(NSArray *)getHearldGameData:(NSDictionary *)response
{
    NSArray *allArray=response[@"result"][@"list"][2][@"tr"];
    NSMutableArray *array = [NSMutableArray array];
    for (NSDictionary *dic in allArray) {
        NBAHeraldGame *game = [NBAHeraldGame getANBAHeraldGameWithDic:dic];
        [array addObject:game];
    }
    return [array copy];
    
}
@end
