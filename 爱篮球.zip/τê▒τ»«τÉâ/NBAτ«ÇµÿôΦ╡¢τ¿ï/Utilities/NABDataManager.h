//
//  NABDataManager.h
//  NBA简易赛程
//
//  Created by tarena on 16/2/25.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NABDataManager : NSObject

/**获取全部数据*/
+(NSDictionary *)getAllNBADataWithJson:(id)response;

/**获取热门比赛数据*/
+(NSDictionary *)getLvieGameTimeData:(NSDictionary*)response;

/**获取球队列表和url*/
+(NSArray *)getAllTeamData:(NSDictionary *)dic;

/**预告比赛列表*/
+(NSArray *)getHearldGameData:(NSDictionary *)response;
@end
